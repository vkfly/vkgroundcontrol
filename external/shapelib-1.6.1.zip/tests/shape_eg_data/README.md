# shapelib test data

Downloaded from [maptools.org](http://dl.maptools.org/dl/shapelib/shape_eg_data.zip).
